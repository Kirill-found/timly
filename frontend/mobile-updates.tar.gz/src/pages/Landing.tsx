/**
 * Лендинг страница Timly
 * Современная публичная страница с подробной информацией о продукте
 */
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  Rocket,
  Trophy,
  Clock,
  Users,
  Brain,
  Target,
  Zap,
  CheckCircle2,
  Star,
  TrendingUp,
  Shield,
  BarChart3,
  FileText,
  Download,
  Eye,
  ThumbsUp,
  Sparkles,
  ArrowRight,
  ChevronDown,
  Play,
  MessageSquare,
  Award,
  Lightbulb,
} from 'lucide-react';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

const Landing: React.FC = () => {
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  // Анимационные варианты
  const fadeInUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const scaleIn = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: { opacity: 1, scale: 1 },
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-purple-50">
      {/* Hero секция с анимацией */}
      <section className="relative overflow-hidden">
        {/* Декоративные элементы */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div
            animate={{
              scale: [1, 1.2, 1],
              opacity: [0.3, 0.5, 0.3],
            }}
            transition={{
              duration: 8,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="absolute -top-40 -right-40 w-96 h-96 bg-blue-400 rounded-full blur-3xl"
          />
          <motion.div
            animate={{
              scale: [1, 1.3, 1],
              opacity: [0.2, 0.4, 0.2],
            }}
            transition={{
              duration: 10,
              repeat: Infinity,
              ease: 'easeInOut',
              delay: 1,
            }}
            className="absolute -bottom-40 -left-40 w-96 h-96 bg-purple-400 rounded-full blur-3xl"
          />
        </div>

        <div className="container relative mx-auto px-4 py-20">
          <motion.div
            initial="hidden"
            animate="visible"
            variants={staggerContainer}
            className="text-center space-y-8"
          >
            {/* Логотип с анимацией */}
            <motion.div variants={scaleIn} className="flex justify-center mb-6">
              <div className="relative">
                <motion.div
                  animate={{
                    boxShadow: [
                      '0 0 20px rgba(59, 130, 246, 0.5)',
                      '0 0 60px rgba(147, 51, 234, 0.5)',
                      '0 0 20px rgba(59, 130, 246, 0.5)',
                    ],
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                  className="h-32 w-32 rounded-3xl overflow-hidden"
                >
                  <img
                    src="/logo.jpg"
                    alt="Timly Logo"
                    className="h-full w-full object-cover"
                  />
                </motion.div>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
                  className="absolute -inset-2 border-4 border-dashed border-blue-400 rounded-3xl"
                />
              </div>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <Badge className="mb-4 text-sm px-4 py-2 bg-gradient-to-r from-blue-600 to-purple-600">
                <Sparkles className="w-4 h-4 mr-2 inline" />
                AI-технологии нового поколения
              </Badge>
            </motion.div>

            <motion.h1
              variants={fadeInUp}
              className="text-6xl md:text-7xl font-bold tracking-tight"
            >
              <span className="bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                Timly
              </span>
            </motion.h1>

            <motion.p
              variants={fadeInUp}
              className="text-3xl md:text-4xl font-bold text-gray-800"
            >
              Умный ИИ-помощник для рекрутеров
            </motion.p>

            <motion.p
              variants={fadeInUp}
              className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed"
            >
              Автоматизируйте процесс отбора кандидатов с помощью передовых AI-технологий.
              <br />
              <span className="font-semibold text-blue-600">
                Экономьте до 80% времени
              </span>{' '}
              на первичном скрининге резюме и находите идеальных сотрудников быстрее.
            </motion.p>

            <motion.div variants={fadeInUp} className="flex gap-4 justify-center flex-wrap">
              <Button
                asChild
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transition-all text-lg px-8 py-6"
              >
                <Link to="/register">
                  <Rocket className="mr-2 h-5 w-5" />
                  Начать бесплатно
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="border-2 border-blue-600 text-blue-600 hover:bg-blue-50 text-lg px-8 py-6"
              >
                <Link to="/login">
                  Войти
                  <ChevronDown className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </motion.div>

            <motion.div
              variants={fadeInUp}
              className="flex gap-8 justify-center text-sm text-gray-600 flex-wrap"
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <span>Первые 50 анализов бесплатно</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <span>Без кредитной карты</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                <span>Готов за 2 минуты</span>
              </div>
            </motion.div>
          </motion.div>

          {/* Статистика */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-20"
          >
            {[
              { value: '10,000+', label: 'Проанализировано резюме', icon: FileText },
              { value: '80%', label: 'Экономия времени', icon: Clock },
              { value: '95%', label: 'Точность анализа', icon: Target },
              { value: '500+', label: 'Довольных клиентов', icon: ThumbsUp },
            ].map((stat, i) => (
              <motion.div
                key={i}
                variants={fadeInUp}
                className="text-center p-6 rounded-2xl bg-white/80 backdrop-blur-sm shadow-lg"
              >
                <stat.icon className="w-8 h-8 mx-auto mb-3 text-blue-600" />
                <div className="text-3xl font-bold text-gray-900">{stat.value}</div>
                <div className="text-sm text-gray-600 mt-1">{stat.label}</div>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Возможности продукта */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <Badge className="mb-4 text-sm px-4 py-2">
              <Brain className="w-4 h-4 mr-2 inline" />
              Возможности
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Все инструменты для{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                идеального найма
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Мощная AI-платформа с полным набором функций для автоматизации рекрутинга
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          >
            {[
              {
                icon: Brain,
                title: 'AI-анализ резюме',
                description:
                  'Искусственный интеллект анализирует резюме по 15+ критериям: навыки, опыт, образование, зарплатные ожидания, релокация и многое другое.',
                gradient: 'from-blue-500 to-cyan-500',
              },
              {
                icon: Target,
                title: 'Умное ранжирование',
                description:
                  'Система автоматически выставляет оценки кандидатам и сортирует их по релевантности вакансии. Лучшие кандидаты всегда наверху.',
                gradient: 'from-purple-500 to-pink-500',
              },
              {
                icon: Zap,
                title: 'Мгновенная обработка',
                description:
                  'Анализируйте сотни резюме за минуты. Наша система обрабатывает 100 резюме за 10-15 минут вместо 8 часов ручной работы.',
                gradient: 'from-orange-500 to-red-500',
              },
              {
                icon: FileText,
                title: 'Подробные отчеты',
                description:
                  'Получайте детальные отчеты с сильными и слабыми сторонами каждого кандидата, рекомендациями по дальнейшим действиям.',
                gradient: 'from-green-500 to-emerald-500',
              },
              {
                icon: Download,
                title: 'Экспорт в Excel',
                description:
                  'Выгружайте результаты анализа в красиво оформленные Excel-файлы с графиками, диаграммами и фильтрами для удобной работы.',
                gradient: 'from-indigo-500 to-purple-500',
              },
              {
                icon: BarChart3,
                title: 'Аналитика и статистика',
                description:
                  'Отслеживайте ключевые метрики: среднее время найма, качество кандидатов, конверсию на каждом этапе воронки.',
                gradient: 'from-yellow-500 to-orange-500',
              },
              {
                icon: Users,
                title: 'Интеграция с HH.ru',
                description:
                  'Прямая интеграция с HeadHunter. Автоматическая синхронизация вакансий и откликов. Настройка за 2 минуты.',
                gradient: 'from-pink-500 to-rose-500',
              },
              {
                icon: Shield,
                title: 'Безопасность данных',
                description:
                  'Все данные надежно зашифрованы и хранятся в защищенных дата-центрах. Полное соответствие GDPR и российскому законодательству.',
                gradient: 'from-cyan-500 to-blue-500',
              },
              {
                icon: TrendingUp,
                title: 'Постоянное улучшение',
                description:
                  'AI-модель постоянно обучается и улучшает качество анализа. Регулярные обновления и новые функции каждый месяц.',
                gradient: 'from-violet-500 to-purple-500',
              },
            ].map((feature, i) => (
              <motion.div key={i} variants={fadeInUp}>
                <Card className="h-full hover:shadow-xl transition-all duration-300 border-2 hover:border-blue-200">
                  <CardHeader>
                    <div
                      className={`h-14 w-14 rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4`}
                    >
                      <feature.icon className="h-7 w-7 text-white" />
                    </div>
                    <CardTitle className="text-xl">{feature.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <CardDescription className="text-base leading-relaxed">
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Как это работает */}
      <section className="py-20 bg-gradient-to-br from-blue-50 to-purple-50">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <Badge className="mb-4 text-sm px-4 py-2">
              <Play className="w-4 h-4 mr-2 inline" />
              Процесс
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Начните работу за{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                3 простых шага
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              От регистрации до первых результатов — всего несколько минут
            </p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-12 max-w-5xl mx-auto">
            {[
              {
                step: '1',
                title: 'Подключите HH.ru',
                description:
                  'Зарегистрируйтесь и добавьте API токен HeadHunter в настройках. Это займет всего 1-2 минуты. Подробная инструкция прямо в интерфейсе.',
                icon: Users,
                color: 'blue',
              },
              {
                step: '2',
                title: 'Синхронизируйте данные',
                description:
                  'Нажмите одну кнопку, и система автоматически загрузит все ваши вакансии и отклики кандидатов. Данные обновляются в реальном времени.',
                icon: Zap,
                color: 'purple',
              },
              {
                step: '3',
                title: 'Получите результаты',
                description:
                  'Запустите AI-анализ одним кликом. Через 10-15 минут получите полный отчет с оценками, рекомендациями и готовый список лучших кандидатов.',
                icon: Trophy,
                color: 'pink',
              },
            ].map((step, i) => (
              <motion.div
                key={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeInUp}
                transition={{ delay: i * 0.2 }}
                className="relative"
              >
                <div className="text-center space-y-4">
                  <div
                    className={`w-20 h-20 rounded-full bg-gradient-to-br from-${step.color}-500 to-${step.color}-600 text-white flex items-center justify-center mx-auto text-3xl font-bold shadow-lg`}
                  >
                    {step.step}
                  </div>
                  <div
                    className={`h-16 w-16 rounded-2xl bg-gradient-to-br from-${step.color}-100 to-${step.color}-200 flex items-center justify-center mx-auto`}
                  >
                    <step.icon className={`h-8 w-8 text-${step.color}-600`} />
                  </div>
                  <h3 className="text-2xl font-bold">{step.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{step.description}</p>
                </div>
                {i < 2 && (
                  <div className="hidden md:block absolute top-10 left-full w-12 h-1 bg-gradient-to-r from-gray-300 to-transparent -ml-6" />
                )}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Тарифные планы */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <Badge className="mb-4 text-sm px-4 py-2">
              <Award className="w-4 h-4 mr-2 inline" />
              Тарифы
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Выберите{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                подходящий план
              </span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Начните бесплатно, масштабируйтесь по мере роста
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="grid md:grid-cols-4 gap-6 max-w-7xl mx-auto"
          >
            {[
              {
                name: 'Free',
                price: '0',
                period: 'навсегда',
                description: 'Для первого знакомства',
                features: [
                  '50 анализов резюме',
                  'Базовые функции AI',
                  'Экспорт в Excel',
                  'Email поддержка',
                ],
                color: 'gray',
                popular: false,
              },
              {
                name: 'Starter',
                price: '2,990',
                period: 'в месяц',
                description: 'Для небольших команд',
                features: [
                  '500 анализов в месяц',
                  'Полный AI-анализ',
                  'Все форматы экспорта',
                  'Приоритетная поддержка',
                  'Аналитика и статистика',
                ],
                color: 'blue',
                popular: false,
              },
              {
                name: 'Professional',
                price: '7,990',
                period: 'в месяц',
                description: 'Для активного найма',
                features: [
                  '2000 анализов в месяц',
                  'Расширенный AI-анализ',
                  'Командная работа (5 мест)',
                  'API доступ',
                  'Персональный менеджер',
                  'Кастомные отчеты',
                ],
                color: 'purple',
                popular: true,
              },
              {
                name: 'Enterprise',
                price: 'По запросу',
                period: '',
                description: 'Для крупного бизнеса',
                features: [
                  'Безлимитные анализы',
                  'Индивидуальная AI-модель',
                  'Неограниченные пользователи',
                  'SLA 99.9%',
                  'Выделенный сервер',
                  'Индивидуальные интеграции',
                ],
                color: 'pink',
                popular: false,
              },
            ].map((plan, i) => (
              <motion.div key={i} variants={fadeInUp} className="relative">
                {plan.popular && (
                  <div className="absolute -top-4 left-0 right-0 flex justify-center">
                    <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-1">
                      <Star className="w-3 h-3 mr-1 inline" />
                      Популярный
                    </Badge>
                  </div>
                )}
                <Card
                  className={`h-full ${
                    plan.popular
                      ? 'border-purple-600 border-2 shadow-2xl scale-105'
                      : 'border-gray-200'
                  } hover:shadow-xl transition-all duration-300`}
                >
                  <CardHeader className="text-center">
                    <CardTitle className="text-2xl mb-2">{plan.name}</CardTitle>
                    <div className="mb-2">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      {plan.period && <span className="text-gray-600 ml-2">₽</span>}
                    </div>
                    <CardDescription className="text-sm">{plan.period}</CardDescription>
                    <p className="text-sm text-gray-600 mt-2">{plan.description}</p>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button
                      asChild
                      className={`w-full ${
                        plan.popular
                          ? 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700'
                          : ''
                      }`}
                      variant={plan.popular ? 'default' : 'outline'}
                    >
                      <Link to="/register">
                        {plan.name === 'Enterprise' ? 'Связаться' : 'Попробовать'}
                      </Link>
                    </Button>
                    <ul className="space-y-3">
                      {plan.features.map((feature, j) => (
                        <li key={j} className="flex items-start gap-2 text-sm">
                          <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                          <span>{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-20 bg-gradient-to-br from-slate-50 to-blue-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <Badge className="mb-4 text-sm px-4 py-2">
              <MessageSquare className="w-4 h-4 mr-2 inline" />
              FAQ
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Часто задаваемые{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                вопросы
              </span>
            </h2>
            <p className="text-xl text-gray-600">
              Ответы на популярные вопросы о работе платформы
            </p>
          </motion.div>

          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
            className="space-y-4"
          >
            {[
              {
                q: 'Как работает AI-анализ резюме?',
                a: 'Наша AI-система использует передовые алгоритмы машинного обучения для анализа резюме по 15+ критериям. Мы оцениваем навыки, опыт работы, образование, зарплатные ожидания, готовность к релокации и многие другие факторы. Система сравнивает профиль кандидата с требованиями вакансии и выставляет оценку от 0 до 100 баллов.',
              },
              {
                q: 'Сколько времени занимает анализ?',
                a: 'Анализ 100 резюме занимает примерно 10-15 минут. Это в 30-40 раз быстрее, чем ручная обработка. Для сравнения: рекрутер тратит около 5-7 минут на просмотр одного резюме, что занимает 8+ часов для 100 кандидатов. С Timly вы получаете результаты за кофе-брейк.',
              },
              {
                q: 'Нужна ли интеграция с HH.ru?',
                a: 'Да, для работы платформы необходим API токен HeadHunter. Это позволяет автоматически синхронизировать ваши вакансии и отклики кандидатов. Получение токена бесплатно и занимает 2 минуты. Подробная инструкция доступна в настройках платформы.',
              },
              {
                q: 'Какая точность анализа?',
                a: 'Точность нашей AI-модели составляет 95%. Мы постоянно обучаем систему на реальных данных и обратной связи от рекрутеров. Модель учитывает контекст вакансии, индустрию, уровень позиции и дает персонализированные рекомендации для каждого случая.',
              },
              {
                q: 'Можно ли экспортировать результаты?',
                a: 'Да! Вы можете выгрузить результаты анализа в красиво оформленный Excel-файл с графиками, диаграммами, условным форматированием и фильтрами. Файл содержит детальную информацию по каждому кандидату, сводную статистику и рекомендации.',
              },
              {
                q: 'Безопасны ли мои данные?',
                a: 'Абсолютно. Мы используем шифрование данных на уровне банков (AES-256), все данные хранятся в защищенных дата-центрах в России. Мы полностью соответствуем требованиям GDPR и ФЗ-152. Доступ к данным имеете только вы и ваша команда.',
              },
              {
                q: 'Как начать работу бесплатно?',
                a: 'Просто зарегистрируйтесь на платформе — получите 50 бесплатных анализов без необходимости вводить данные кредитной карты. Этого достаточно, чтобы оценить качество работы системы и принять решение о продолжении использования.',
              },
              {
                q: 'Есть ли поддержка?',
                a: 'Да! Мы предоставляем email-поддержку для всех пользователей (ответ в течение 24 часов), приоритетную поддержку для платных тарифов (ответ в течение 4 часов) и персонального менеджера для Professional и Enterprise планов.',
              },
            ].map((faq, i) => (
              <motion.div key={i} variants={fadeInUp}>
                <Card
                  className="cursor-pointer hover:shadow-lg transition-all"
                  onClick={() => setActiveFaq(activeFaq === i ? null : i)}
                >
                  <CardHeader>
                    <div className="flex justify-between items-center">
                      <CardTitle className="text-lg">{faq.q}</CardTitle>
                      <ChevronDown
                        className={`w-5 h-5 transition-transform ${
                          activeFaq === i ? 'rotate-180' : ''
                        }`}
                      />
                    </div>
                  </CardHeader>
                  {activeFaq === i && (
                    <CardContent>
                      <p className="text-gray-600 leading-relaxed">{faq.a}</p>
                    </CardContent>
                  )}
                </Card>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Преимущества перед конкурентами */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeInUp}
            className="text-center mb-16"
          >
            <Badge className="mb-4 text-sm px-4 py-2">
              <Lightbulb className="w-4 h-4 mr-2 inline" />
              Почему Timly
            </Badge>
            <h2 className="text-4xl md:text-5xl font-bold mb-4">
              Преимущества перед{' '}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                ручным отбором
              </span>
            </h2>
          </motion.div>

          <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeInUp}
            >
              <Card className="h-full border-2 border-red-200 bg-red-50/50">
                <CardHeader>
                  <CardTitle className="text-2xl text-red-700 flex items-center gap-2">
                    <Eye className="w-6 h-6" />
                    Ручной отбор
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start gap-2 text-red-600">
                    <span className="text-xl">✗</span>
                    <span>8+ часов на просмотр 100 резюме</span>
                  </div>
                  <div className="flex items-start gap-2 text-red-600">
                    <span className="text-xl">✗</span>
                    <span>Субъективная оценка кандидатов</span>
                  </div>
                  <div className="flex items-start gap-2 text-red-600">
                    <span className="text-xl">✗</span>
                    <span>Риск пропустить сильного кандидата</span>
                  </div>
                  <div className="flex items-start gap-2 text-red-600">
                    <span className="text-xl">✗</span>
                    <span>Нет структурированной аналитики</span>
                  </div>
                  <div className="flex items-start gap-2 text-red-600">
                    <span className="text-xl">✗</span>
                    <span>Сложно сравнивать кандидатов</span>
                  </div>
                  <div className="flex items-start gap-2 text-red-600">
                    <span className="text-xl">✗</span>
                    <span>Высокая стоимость рабочего времени</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            <motion.div
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeInUp}
              transition={{ delay: 0.2 }}
            >
              <Card className="h-full border-2 border-green-200 bg-green-50/50">
                <CardHeader>
                  <CardTitle className="text-2xl text-green-700 flex items-center gap-2">
                    <Brain className="w-6 h-6" />
                    Timly AI
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-start gap-2 text-green-600">
                    <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <span>10-15 минут на анализ 100 резюме</span>
                  </div>
                  <div className="flex items-start gap-2 text-green-600">
                    <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <span>Объективная оценка по 15+ критериям</span>
                  </div>
                  <div className="flex items-start gap-2 text-green-600">
                    <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <span>Точность 95% - не упустите таланты</span>
                  </div>
                  <div className="flex items-start gap-2 text-green-600">
                    <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <span>Детальная аналитика и отчеты</span>
                  </div>
                  <div className="flex items-start gap-2 text-green-600">
                    <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <span>Автоматическое ранжирование кандидатов</span>
                  </div>
                  <div className="flex items-start gap-2 text-green-600">
                    <CheckCircle2 className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <span>Экономия до 80% бюджета на рекрутинг</span>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA секция */}
      <section className="py-20 bg-gradient-to-br from-blue-600 via-purple-600 to-pink-600 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC40Ij48cGF0aCBkPSJNMzYgMzBoLTJWMGgydjMwem0wIDMwdi0yaDMwdjJIMzZ6TTAgMzBoMzB2Mkgwdi0yem0zMCAwVjBoMnYzMGgtMnoiLz48L2c+PC9nPjwvc3ZnPg==')]" />
        </div>

        <div className="container relative mx-auto px-4 text-center">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={staggerContainer}
          >
            <motion.div variants={fadeInUp}>
              <Badge className="mb-6 text-sm px-4 py-2 bg-white/20 text-white border-white/30">
                <Sparkles className="w-4 h-4 mr-2 inline" />
                Присоединяйтесь к успешным компаниям
              </Badge>
            </motion.div>

            <motion.h2
              variants={fadeInUp}
              className="text-4xl md:text-6xl font-bold mb-6 text-white"
            >
              Готовы революционизировать найм?
            </motion.h2>

            <motion.p variants={fadeInUp} className="text-xl mb-8 text-white/90 max-w-2xl mx-auto">
              Начните бесплатно прямо сейчас. Первые 50 анализов — в подарок.
              <br />
              Кредитная карта не требуется.
            </motion.p>

            <motion.div
              variants={fadeInUp}
              className="flex gap-4 justify-center flex-wrap mb-8"
            >
              <Button
                asChild
                size="lg"
                className="bg-white text-purple-600 hover:bg-gray-100 shadow-2xl text-lg px-10 py-7"
              >
                <Link to="/register">
                  <Rocket className="mr-2 h-6 w-6" />
                  Начать бесплатно
                  <ArrowRight className="ml-2 h-6 w-6" />
                </Link>
              </Button>
              <Button
                asChild
                variant="outline"
                size="lg"
                className="border-2 border-white text-white hover:bg-white/10 text-lg px-10 py-7"
              >
                <Link to="/login">Уже есть аккаунт</Link>
              </Button>
            </motion.div>

            <motion.div
              variants={fadeInUp}
              className="flex gap-8 justify-center text-white/90 flex-wrap"
            >
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5" />
                <span>Быстрая регистрация</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5" />
                <span>50 анализов бесплатно</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5" />
                <span>Без автоплатежей</span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-slate-900 text-white">
        <div className="container mx-auto px-4 py-12">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <img src="/logo.jpg" alt="Timly" className="h-12 w-12 rounded-xl object-cover" />
                <span className="text-2xl font-bold">Timly</span>
              </div>
              <p className="text-gray-400 text-sm">
                AI-платформа для автоматизации отбора кандидатов
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Продукт</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link to="/register" className="hover:text-white transition-colors">
                    Возможности
                  </Link>
                </li>
                <li>
                  <Link to="/register" className="hover:text-white transition-colors">
                    Тарифы
                  </Link>
                </li>
                <li>
                  <Link to="/register" className="hover:text-white transition-colors">
                    Интеграции
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Компания</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link to="/register" className="hover:text-white transition-colors">
                    О нас
                  </Link>
                </li>
                <li>
                  <Link to="/register" className="hover:text-white transition-colors">
                    Блог
                  </Link>
                </li>
                <li>
                  <Link to="/register" className="hover:text-white transition-colors">
                    Контакты
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Поддержка</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>
                  <Link to="/register" className="hover:text-white transition-colors">
                    Документация
                  </Link>
                </li>
                <li>
                  <Link to="/register" className="hover:text-white transition-colors">
                    FAQ
                  </Link>
                </li>
                <li>
                  <Link to="/register" className="hover:text-white transition-colors">
                    Техподдержка
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-gray-400">
            <p>&copy; 2024 Timly. AI-powered Resume Screening Platform. Все права защищены.</p>
            <div className="flex gap-6">
              <Link to="/login" className="hover:text-white transition-colors">
                Политика конфиденциальности
              </Link>
              <Link to="/login" className="hover:text-white transition-colors">
                Условия использования
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
